AH
ahewdev.com

Hovercraft is a small but growing collection of jQuery and CSS3 hover effects
Feel free to use them commercially
Click on the html files in this folder to demo each effect.
All of the code is in the corresponding html file


To Implement into Project:
-***MAKE SURE YOU HAVE THESE TWO SCRIPT LINES IN THE HEAD OF YOUR DOC:
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="include/jquery-ui.js"></script>
-**MAKE SURE YOU HAVE THE 'include' FOLDER INSIDE YOU OWN PROJECT DIRECTORY
-You may take out unessecary files out of the include folder, such as images
-Copy jQury code into another .js file, or inside script tage on your HTML page
-Copy css into another css file, or inside style tags on your HTML page
-Copy HTML tags into your HTML file
-To add new elements with the same effects, simple add the corresponding class to most any element
-For example: <div class="background-fade"></div>
-Thats it

Thanks for actually reading the readme file.

HOVERCRAFT is small... but it will continue to grow